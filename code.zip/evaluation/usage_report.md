# Token usage report

The final full-dataset run is pending dataset mounting. No model calls were made by the current deterministic scaffold, so input tokens, output tokens, cost, and averages are currently 0.00. The production runner must record provider, model name, call count, input tokens, output tokens, estimated cost, and per-request averages here after the evidence-grounded AI audit is enabled. No credentials are stored in this report.
