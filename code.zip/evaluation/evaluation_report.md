# Evaluation report

## Status and field accuracy
The evaluation harness compares `output.csv` to the supplied `sample_output.csv` and reports case-level deletion status accuracy, step-level operation/state accuracy, field-level system/resource/evidence accuracy, and sequence accuracy. The production run is intended to execute against all 518 requests after `dataset/` is mounted.

## Additional evaluation cases
1. A request with a deleted primary account but a retained tombstone: expect `INCOMPLETE` when direct identifiers remain and `REDACT_RECORD` before `VERIFY_RECORD_REDACTED`.
2. A request whose backup restore job is still active: expect `INCOMPLETE`, `BLOCK_RESTORE`, then `VERIFY_RESTORE_BLOCKED`.
3. A customer with no authorized deletion request: expect `NOT_APPLICABLE` and `[]`.

## Failures found and improvements
The initial scaffold could not produce evidence-grounded answers without the participant dataset. The solver now fails loudly when `dataset/deletion_requests.csv` is absent rather than emitting fabricated rows. The next improvement is to replace the baseline classification with identity resolution across current and historical identifiers, evidence parsing for CSV/PDF/image/SQLite inputs, deterministic policy evaluation, and a token/cost ledger for every model call.
