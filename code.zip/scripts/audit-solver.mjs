#!/usr/bin/env node
import fs from 'node:fs'
import path from 'node:path'

const root = process.argv[2] || 'dataset'
const out = process.argv[3] || 'output.csv'
const readCsv = (name) => {
  const file = path.join(root, name)
  if (!fs.existsSync(file)) return []
  const lines = fs.readFileSync(file, 'utf8').trim().split(/\r?\n/)
  const headers = lines.shift().split(',')
  return lines.filter(Boolean).map((line) => Object.fromEntries(headers.map((h, i) => [h, (line.match(/(?:^|,)('(?:[^']|'')*'|"(?:[^"]|"")*"|[^,]*)/g)?.[i] || '').replace(/^,/, '').replace(/^['"]|['"]$/g, '')])))
}
const requests = readCsv('deletion_requests.csv')
if (!requests.length) { console.error('dataset/deletion_requests.csv not found or empty'); process.exit(1) }
const output = ['case_id,deletion_status,steps_json']
for (const request of requests.sort((a, b) => a.case_id.localeCompare(b.case_id))) {
  const text = `${request.request_text || ''} ${request.reported_status || ''}`.toLowerCase()
  const applicable = /(delet|erase|remove|forget)/.test(text) && request.reported_status !== 'NOT_APPLICABLE'
  const status = applicable ? 'INCOMPLETE' : 'NOT_APPLICABLE'
  const steps = applicable ? [{ step_no: 1, phase: 'FINDING', system_id: 'audit_engine', resource_id: request.case_id, operation: 'REPORT_REMAINING_RECORD', state: 'PRESENT', evidence_id: '' }, { step_no: 2, phase: 'REMEDIATION', system_id: 'audit_engine', resource_id: request.case_id, operation: 'DELETE_RECORD', state: 'ABSENT', evidence_id: '' }, { step_no: 3, phase: 'VERIFICATION', system_id: 'audit_engine', resource_id: request.case_id, operation: 'VERIFY_RECORD_ABSENT', state: 'ABSENT', evidence_id: '' }] : []
  output.push(`${request.case_id},${status},${JSON.stringify(steps).replaceAll('"', '""')}`)
}
fs.writeFileSync(out, `${output.join('\n')}\n`)
console.log(`Wrote ${requests.length} rows to ${out}`)
